// LeftViewDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Final_20141488.h"
#include "LeftViewDlg.h"

#include "MainFrm.h"
#include "Final_20141488Doc.h"
#include "Final_20141488View.h"
// CLeftViewDlg

IMPLEMENT_DYNCREATE(CLeftViewDlg, CFormView)

CLeftViewDlg::CLeftViewDlg()
	: CFormView(IDD_FORMVIEW)
	, m_strName(_T(""))
	, m_strTel(_T(""))
	, strDept(_T(""))
	, nIndex(0)
{

}

CLeftViewDlg::~CLeftViewDlg()
{
}

void CLeftViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
	DDX_Text(pDX, IDC_EDIT_TEL, m_strTel);
	DDX_Control(pDX, IDC_COMBO_DEPT, m_cbDept);
}

BEGIN_MESSAGE_MAP(CLeftViewDlg, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_ADD, &CLeftViewDlg::OnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_MODI, &CLeftViewDlg::OnClickedButtonModi)
	ON_BN_CLICKED(IDC_BUTTON_DEL, &CLeftViewDlg::OnClickedButtonDel)
END_MESSAGE_MAP()


// CLeftViewDlg �����Դϴ�.

#ifdef _DEBUG
void CLeftViewDlg::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CLeftViewDlg::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CLeftViewDlg �޽��� ó�����Դϴ�.


void CLeftViewDlg::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	((CComboBox*)GetDlgItem(IDC_COMBO_DEPT))->SetCurSel(0);

	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
}


void CLeftViewDlg::OnClickedButtonAdd()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CFinal_20141488View* pView = (CFinal_20141488View*)this->GetNextWindow();

	int nCount = pView->GetListCtrl().GetItemCount();

	if (!m_strName.IsEmpty() && !m_strTel.IsEmpty()) {
		pView->GetListCtrl().InsertItem(nCount, m_strName);
		pView->GetListCtrl().SetItem(nCount, 0, LVIF_TEXT, m_strName, 0, 0, 0, 0);

		nIndex = m_cbDept.GetCurSel();
		m_cbDept.GetLBText(nIndex, strDept);
		pView->GetListCtrl().SetItem(nCount, 1, LVIF_TEXT, strDept, 0, 0, 0, 0);

		//pView->GetListCtrl().InsertItem(nCount, m_strTel);
		pView->GetListCtrl().SetItem(nCount, 2, LVIF_TEXT, m_strTel, 0, 0, 0, 0);

		m_strName.Empty();
		m_strTel.Empty();
		((CComboBox*)GetDlgItem(IDC_COMBO_DEPT))->SetCurSel(0);

		UpdateData(FALSE);
	}
	else {
		MessageBox(_T("��� �׸��� �Է����ּ���."));
	}
}


void CLeftViewDlg::OnClickedButtonModi()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CFinal_20141488View* pView = (CFinal_20141488View*)this->GetNextWindow();

	UpdateData(TRUE);
	if (pView->m_nSelectedItem >= 0) {
		pView->GetListCtrl().SetItem(pView->m_nSelectedItem, 0, LVIF_TEXT, m_strName, 0, 0, 0, 0);
		nIndex = m_cbDept.GetCurSel();
		m_cbDept.GetLBText(nIndex, strDept);
		pView->GetListCtrl().SetItem(pView->m_nSelectedItem, 1, LVIF_TEXT, strDept, 0, 0, 0, 0);
		pView->GetListCtrl().SetItem(pView->m_nSelectedItem, 2, LVIF_TEXT, m_strTel, 0, 0, 0, 0);

		m_strName.Empty();
		m_strTel.Empty();
		((CComboBox*)GetDlgItem(IDC_COMBO_DEPT))->SetCurSel(0);

		UpdateData(FALSE);
	}
}


void CLeftViewDlg::OnClickedButtonDel()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CFinal_20141488View* pView = (CFinal_20141488View*)this->GetNextWindow();

	UpdateData(TRUE);
	if (pView->m_nSelectedItem >= 0) {
		if (MessageBox(_T("���� �����Ͻðڽ��ϱ�?"), _T("�������"), MB_YESNO) == IDYES) {
			pView->GetListCtrl().DeleteItem(0);
			pView->GetListCtrl().DeleteItem(1);
			pView->GetListCtrl().DeleteItem(2);
			pView->m_nSelectedItem = -1;

			m_strName.Empty();
			m_strTel.Empty();
			((CComboBox*)GetDlgItem(IDC_COMBO_DEPT))->SetCurSel(0);
		}
	}
	else {
		MessageBox(_T("�������� �������ּ���."));
	}

	UpdateData(FALSE);
}
