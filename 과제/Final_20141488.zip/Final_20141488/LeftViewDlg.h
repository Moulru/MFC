#pragma once
#include "afxwin.h"



// CLeftViewDlg �� ���Դϴ�.

class CLeftViewDlg : public CFormView
{
	DECLARE_DYNCREATE(CLeftViewDlg)

protected:
	CLeftViewDlg();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CLeftViewDlg();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FORMVIEW };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString m_strName;
	CString m_strTel;
	CComboBox m_cbDept;
	virtual void OnInitialUpdate();
	afx_msg void OnClickedButtonAdd();
	CString strDept;
	afx_msg void OnClickedButtonModi();
	int nIndex;
	afx_msg void OnClickedButtonDel();
};


