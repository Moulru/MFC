// HobbyCtrl.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488_5.h"
#include "HobbyCtrl.h"
#include "afxdialogex.h"

#include "MainFrm.h"
#include "20141488_5Doc.h"
#include "20141488_5View.h"

// CHobbyCtrl ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CHobbyCtrl, CDialogEx)

CHobbyCtrl::CHobbyCtrl(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_strName(_T(""))
	, m_bSex(true)
{
	m_bChecked[0] = m_bChecked[1] = m_bChecked[2] = false;

}

CHobbyCtrl::~CHobbyCtrl()
{
}

void CHobbyCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_HOBBY, m_listHobby);
	DDX_Control(pDX, IDC_COMBO_SEX, m_cbSex);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
}


BEGIN_MESSAGE_MAP(CHobbyCtrl, CDialogEx)
	ON_CBN_SELCHANGE(IDC_COMBO_SEX, &CHobbyCtrl::OnSelchangeComboSex)
	ON_COMMAND(IDC_RADIO_MALE, &CHobbyCtrl::OnRadioMale)
	ON_COMMAND(IDC_RADIO_FEMALE, &CHobbyCtrl::OnRadioFemale)
	ON_LBN_SELCHANGE(IDC_LIST_HOBBY, &CHobbyCtrl::OnSelchangeListHobby)
	ON_BN_CLICKED(IDC_CHECK_READING, &CHobbyCtrl::OnClickedCheckReading)
	ON_BN_CLICKED(IDC_CHECK_FISHING, &CHobbyCtrl::OnClickedCheckFishing)
	ON_BN_CLICKED(IDC_CHECK_SPORTS, &CHobbyCtrl::OnClickedCheckSports)
	ON_BN_CLICKED(IDC_BUTTON_RESULT, &CHobbyCtrl::OnClickedButtonResult)
END_MESSAGE_MAP()


// CHobbyCtrl �޽��� ó�����Դϴ�.


BOOL CHobbyCtrl::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_listHobby.AddString(_T("����"));
	m_listHobby.AddString(_T("����"));
	m_listHobby.AddString(_T("�"));

	m_cbSex.SetCurSel(0);
	((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(TRUE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CHobbyCtrl::OnSelchangeComboSex()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	switch (m_cbSex.GetCurSel())
	{
	case 0:
		if (m_bSex == false) {
			((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(TRUE);
			((CButton*)GetDlgItem(IDC_RADIO_FEMALE))->SetCheck(FALSE);
			m_bSex = true;
		}
		break;
	case 1:
		if (m_bSex == true) {
			((CButton*)GetDlgItem(IDC_RADIO_FEMALE))->SetCheck(TRUE);
			((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(FALSE);
			m_bSex = false;
		}
		break;
	}
}


void CHobbyCtrl::OnRadioMale()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	if (m_bSex == false) {
		m_bSex = true;
		m_cbSex.SetCurSel(0);
	}
}


void CHobbyCtrl::OnRadioFemale()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	if (m_bSex == true) {
		m_bSex = false;
		m_cbSex.SetCurSel(1);
	}
}


void CHobbyCtrl::OnSelchangeListHobby()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	switch (m_listHobby.GetCurSel())
	{
	case 0:
		if (m_bChecked[0] == false) {
			((CButton*)GetDlgItem(IDC_CHECK_READING))->SetCheck(TRUE);
			m_bChecked[0] = true;
		}
		else {
			((CButton*)GetDlgItem(IDC_CHECK_READING))->SetCheck(FALSE);
			m_bChecked[0] = false;
		}
		break;
	case 1:
		if (m_bChecked[1] == false) {
			((CButton*)GetDlgItem(IDC_CHECK_FISHING))->SetCheck(TRUE);
			m_bChecked[1] = true;
		}
		else {
			((CButton*)GetDlgItem(IDC_CHECK_FISHING))->SetCheck(FALSE);
			m_bChecked[1] = false;
		}
		break;
	case 2:
		if (m_bChecked[2] == false) {
			((CButton*)GetDlgItem(IDC_CHECK_SPORTS))->SetCheck(TRUE);
			m_bChecked[2] = true;
		}
		else {
			((CButton*)GetDlgItem(IDC_CHECK_SPORTS))->SetCheck(FALSE);
			m_bChecked[2] = false;
		}
		break;
	}
}


void CHobbyCtrl::OnClickedCheckReading()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (m_bChecked[0] == false) {
		m_bChecked[0] = true;
		m_listHobby.SetSel(0,TRUE);
	}
	else {
		m_bChecked[0] = false;
		m_listHobby.SetSel(0,FALSE);
	}
}


void CHobbyCtrl::OnClickedCheckFishing()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (m_bChecked[1] == false) {
		m_bChecked[1] = true;
		m_listHobby.SetSel(1, TRUE);
	}
	else {
		m_bChecked[1] = false;
		m_listHobby.SetSel(1, FALSE);
	}
}


void CHobbyCtrl::OnClickedCheckSports()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (m_bChecked[2] == false) {
		m_bChecked[2] = true;
		m_listHobby.SetSel(2, TRUE);
	}
	else {
		m_bChecked[2] = false;
		m_listHobby.SetSel(2, FALSE);
	}
}


void CHobbyCtrl::OnClickedButtonResult()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_5View* vPoint = (CMy20141488_5View*)pFrame->GetActiveView();

	GetDlgItemText(IDC_EDIT_NAME, vPoint->m_strName);
	UpdateData(TRUE);

	m_cbSex.GetLBText(m_cbSex.GetCurSel(), vPoint->m_strSex);

	vPoint->m_strHobby= "";

	for (int i = 0; i < 3; i++) {
		CString str;
		if (m_bChecked[i] == TRUE) {
			m_listHobby.GetText(i, str);
			vPoint->m_strHobby += str + _T(" ");
		}
	}

	vPoint->Invalidate();
}
