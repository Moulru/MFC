//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 20141488_10.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_FORMVIEW                    101
#define IDR_MAINFRAME                   128
#define IDR_My20141488_10TYPE           130
#define IDC_EDIT_TEXT                   1000
#define IDC_BUTTON_ADD                  1001
#define IDC_EDIT_VIEW                   1002
#define IDC_CHECK1                      1005
#define IDC_CHECK_MORE                  1005
#define IDC_BUTTON_EDT                  1006
#define IDC_BUTTON_DEL                  1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        311
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
