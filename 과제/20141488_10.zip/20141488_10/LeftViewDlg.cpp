// LeftViewDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488_10.h"
#include "LeftViewDlg.h"


// CLeftViewDlg

IMPLEMENT_DYNCREATE(CLeftViewDlg, CFormView)

CLeftViewDlg::CLeftViewDlg()
	: CFormView(IDD_FORMVIEW)
	, m_strNodeText(_T(""))
	, m_strSelectedNode(_T(""))
	, m_bChecked(false)
{

}

CLeftViewDlg::~CLeftViewDlg()
{
}

void CLeftViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_TEXT, m_strNodeText);
	DDX_Text(pDX, IDC_EDIT_VIEW, m_strSelectedNode);
	//  DDX_Control(pDX, IDC_CHECK_MORE, m_checkMore);
	DDX_Control(pDX, IDC_CHECK_MORE, m_checkMore);
}

BEGIN_MESSAGE_MAP(CLeftViewDlg, CFormView)
END_MESSAGE_MAP()


// CLeftViewDlg �����Դϴ�.

#ifdef _DEBUG
void CLeftViewDlg::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CLeftViewDlg::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CLeftViewDlg �޽��� ó�����Դϴ�.
