// SizeDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488P8_1.h"
#include "SizeDlg.h"
#include "afxdialogex.h"
#include "20141488P8_1Dlg.h"

// CSizeDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSizeDlg, CDialogEx)

CSizeDlg::CSizeDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_SIZE, pParent)
	, m_nVertical(50)
	, m_nHorizon(50)
	, m_bSameRatio(false)
{

}

CSizeDlg::~CSizeDlg()
{
}

void CSizeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER_HORIZONTAL, m_sliderHorizon);
	DDX_Control(pDX, IDC_SLIDER_VERTICAL, m_sliderVertical);
	//  DDX_Text(pDX, IDC_EDIT_HORIZONTAL, m_nVertical);
	DDX_Text(pDX, IDC_EDIT_HORIZONTAL, m_nHorizon);
	DDX_Text(pDX, IDC_EDIT_VERTICAL, m_nVertical);
	DDX_Control(pDX, IDC_CHECK_SAME_RATIO, m_checkSameRatio);
}


BEGIN_MESSAGE_MAP(CSizeDlg, CDialogEx)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_CHECK_SAME_RATIO, &CSizeDlg::OnClickedCheckSameRatio)
END_MESSAGE_MAP()


// CSizeDlg �޽��� ó�����Դϴ�.


BOOL CSizeDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_sliderHorizon.SetRange(0, 100);
	m_sliderVertical.SetRange(0, 100);
	m_sliderHorizon.SetPos(50);
	m_sliderVertical.SetPos(50);
	m_bSameRatio = TRUE;
	m_checkSameRatio.SetCheck(1);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CSizeDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CMy20141488P8_1Dlg* pMaindlg = (CMy20141488P8_1Dlg*)AfxGetMainWnd();

	int nHorizon = m_sliderHorizon.GetPos();
	int nVertical = m_sliderVertical.GetPos();

	if (pScrollBar->GetSafeHwnd() == m_sliderHorizon.m_hWnd) {
		if (m_bSameRatio == TRUE) {
			m_nHorizon = nHorizon;
			m_nVertical = nVertical;
			m_sliderVertical.SetPos(nHorizon);
		}
		m_nHorizon = nHorizon;
	}
	else if (pScrollBar->GetSafeHwnd() == m_sliderVertical.m_hWnd) {
		if (m_bSameRatio == TRUE) {
			m_nHorizon = nHorizon;
			m_nVertical = nVertical;
			m_sliderHorizon.SetPos(nVertical);
		}
		m_nVertical = nVertical;
	}
	else {
		return;
	}

	pMaindlg->m_nCurHScale = nHorizon;
	pMaindlg->m_nCurVScale = nVertical;

	UpdateData(FALSE);
	pMaindlg->UpdateDrawing();
	CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CSizeDlg::OnClickedCheckSameRatio()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_bSameRatio = !m_bSameRatio;
}
