#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CSizeDlg ��ȭ �����Դϴ�.

class CSizeDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CSizeDlg)

public:
	CSizeDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSizeDlg();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_SIZE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CSliderCtrl m_sliderHorizon;
	CSliderCtrl m_sliderVertical;
//	int m_nVertical;
	int m_nHorizon;
	int m_nVertical;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnClickedCheckSameRatio();
	bool m_bSameRatio;
	CButton m_checkSameRatio;
};
