// NCardListBox.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488P9_1.h"
#include "NCardListBox.h"
#include "20141488P9_1Dlg.h"

// CNCardListBox

IMPLEMENT_DYNAMIC(CNCardListBox, CVSListBox)

CNCardListBox::CNCardListBox()
{

}

CNCardListBox::~CNCardListBox()
{
}


BEGIN_MESSAGE_MAP(CNCardListBox, CVSListBox)
END_MESSAGE_MAP()



// CNCardListBox �޽��� ó�����Դϴ�.




void CNCardListBox::OnAfterAddItem(int nIndex)
{
	CMy20141488P9_1Dlg* pParent = (CMy20141488P9_1Dlg*)GetParent();
	pParent->AddNameCard(GetItemText(nIndex));
}


void CNCardListBox::OnSelectionChanged()
{
	int nItem;
	if ((nItem = GetSelItem()) < 0) {
		return;
	}

	CMy20141488P9_1Dlg* pParent = (CMy20141488P9_1Dlg*)GetParent();
	pParent->AddNameCard(GetItemText(nItem));
}


BOOL CNCardListBox::OnBeforeRemoveItem(int nIndex)
{
	CMy20141488P9_1Dlg* pParent = (CMy20141488P9_1Dlg*)GetParent();
	pParent->DeleteNameCard(GetSelItem());

	return true;
}
