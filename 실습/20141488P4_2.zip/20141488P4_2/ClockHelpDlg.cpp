// ClockHelpDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488P4_2.h"
#include "ClockHelpDlg.h"
#include "afxdialogex.h"


// CClockHelpDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CClockHelpDlg, CDialogEx)

CClockHelpDlg::CClockHelpDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_HELP, pParent)
{

}

CClockHelpDlg::~CClockHelpDlg()
{
}

void CClockHelpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CClockHelpDlg, CDialogEx)
END_MESSAGE_MAP()


// CClockHelpDlg �޽��� ó�����Դϴ�.
